import CoolProp, csv
from CoolProp.CoolProp import PropsSI

with open('methane.csv','w',newline="") as fobj:
    fobj_writer = csv.writer(fobj)
    fobj_writer.writerow(['Pressure (Pa)','Temperature (K)','Density (kg/m3)'])
    for pressure in [(2+0.1*i)*10**6 for i in range(21)]:
        for temper in [110+5*i for i in range(15)]:
            try:
                density = PropsSI('D','P',pressure,'T',temper,'Methane')
                fobj_writer.writerow([pressure,temper,density])
            except Exception:
                pass

    for pressure in [(0.1+0.1*i)*10**6 for i in range(20)]:
        for temper in [220+10*i for i in range(24)]:
            try:
                density = PropsSI('D','P',pressure,'T',temper,'Methane')
                fobj_writer.writerow([pressure,temper,density])
            except Exception:
                pass


with open('r134a.csv','w',newline="") as fobj:
    fobj_writer = csv.writer(fobj)
    fobj_writer.writerow(['Pressure (Pa)','Temperature (K)','Density (kg/m3)'])
    for pressure in [(1+0.1*i)*10**6 for i in range(26)]:
        for temper in [220+5*i for i in range(25)]:
            density = PropsSI('D','P',pressure,'T',temper,'R134a')
            fobj_writer.writerow([pressure,temper,density])

    for pressure in [(0.1+0.1*i)*10**6 for i in range(20)]:
        for temper in [390+10*i for i in range(14)]:
            density = PropsSI('D','P',pressure,'T',temper,'R134a')
            fobj_writer.writerow([pressure,temper,density])
