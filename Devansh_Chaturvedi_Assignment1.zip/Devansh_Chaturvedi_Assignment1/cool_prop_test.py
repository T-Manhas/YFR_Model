import CoolProp
from CoolProp.CoolProp import PropsSI
T_sat = PropsSI('T','P',101325,'Q',0,'Water')
print(T_sat)