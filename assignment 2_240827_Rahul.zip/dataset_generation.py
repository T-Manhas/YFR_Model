import numpy as np
import pandas as pd
from CoolProp.CoolProp import PropsSI

def generate_dataset(fluid, T_range, P_range, filename):
    T_values = np.linspace(T_range[0], T_range[1], 50)
    P_values = np.linspace(P_range[0], P_range[1], 50)

    data = []

    for T in T_values:
        for P in P_values:
            try:
                rho = PropsSI('D', 'T', T, 'P', P, fluid)
                data.append([T, P, rho])
            except:
                continue

    df = pd.DataFrame(data, columns=[
        "Temperature (K)",
        "Pressure (Pa)",
        "Density (kg/m3)"
    ])

    df.to_csv(filename, index=False)
    print(f"{filename} generated successfully.")

# Methane dataset
generate_dataset(
    fluid="Methane",
    T_range=(150, 400),
    P_range=(1e5, 5e6),
    filename="methane_data.csv"
)

# R134a dataset
generate_dataset(
    fluid="R134a",
    T_range=(250, 450),
    P_range=(1e5, 4e6),
    filename="r134a_data.csv"
)
