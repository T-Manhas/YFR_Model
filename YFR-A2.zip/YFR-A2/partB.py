import numpy as np
import pandas as pd
import CoolProp.CoolProp as CP
import os

# 1. Setup Output Directory
output_dir = 'Fluid_saturation_CSVs'
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# 2. Obtain Fluid List and select 50
fluids = CP.get_global_param_string("FluidsList").split(',')
valid_fluids = []
for fluid in fluids:
    if len(valid_fluids) >= 50:
        break
    try:
        CP.PropsSI('T_critical', fluid)
        valid_fluids.append(fluid)
    except:
        continue

master_list = []
stats = {"total": 0, "nans": 0, "non_monotonic": 0, "negatives": 0}

for fluid in valid_fluids:
    try:
        backend_fluid = f"HEOS::{fluid}"

        T_triple = CP.PropsSI('Tmin', backend_fluid)
        T_crit = CP.PropsSI('T_critical', backend_fluid)

        # Domain Padding: T_triple + 2K to T_crit - 2K
        T_grid = np.linspace(T_triple + 2.0, T_crit - 2.0, 100)

        fluid_results = []
        last_P = -1

        for T in T_grid:
            stats['total'] += 1
            try:
                psat = CP.PropsSI('P', 'T', T, 'Q', 0, backend_fluid)
                rholiq = CP.PropsSI('D', 'T', T, 'Q', 0, backend_fluid)
                rhovap = CP.PropsSI('D', 'T', T, 'Q', 1, backend_fluid)

                # Data Cleaning & Validation
                if np.isnan([psat, rholiq, rhovap]).any():
                    stats['nans'] += 1
                    continue
                
                if psat <= 0 or rholiq <= 0 or rhovap <= 0:
                    stats['negatives'] += 1
                    continue

                if psat <= last_P: 
                    stats['non_monotonic'] += 1
                    continue
                
                row = [fluid, T, psat, rholiq, rhovap]
                fluid_results.append(row)
                master_list.append(row)
                last_P = psat

            except Exception:
                stats['nans'] += 1
                continue

        if fluid_results:
            df_ind = pd.DataFrame(fluid_results, 
                                  columns=['Fluid', 'T (K)', 'p_sat (Pa)', 'rho_liq (kg/m³)', 'rho_vap (kg/m³)'])
            df_ind.to_csv(f'{output_dir}/{fluid}_sat.csv', index=False) 

    except Exception:
        continue 

# 3. Save Master Dataset
df_master = pd.DataFrame(master_list, 
                         columns=['Fluid', 'T (K)', 'p_sat (Pa)', 'rho_liq (kg/m³)', 'rho_vap (kg/m³)'])
df_master = df_master.sort_values(by=['Fluid', 'T (K)'])
df_master.to_csv('Master_Saturation_Dataset.csv', index=False) 

print("Success! Datasets generated.")
print(f"Total points attempted: {stats['total']}")
print(f"NaNs removed: {stats['nans']}")