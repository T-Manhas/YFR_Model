clear; close all; clc
% Silence the annoying version-compatibility warnings
warning('off','MATLAB:colon:operandsNotRealScalar');

% Add GPTIPS2 to path
addpath(genpath('E:\New folder (2)\gptips2')); 

% Question C2: Run symbolic regression [cite: 115]
gp = rungp(@config_ethane);

% Question C2 & D1: Plot Pareto Front [cite: 127, 142]
try
    plotpareto(gp); 
catch
    popbrowser(gp);
end
title('Pareto Front: Accuracy v/s Complexity for Ethane \xi');

summary(gp);
warning('on','MATLAB:colon:operandsNotRealScalar');

function gp = config_ethane(gp)
    % FORCE THE PATH: Points to your Python output folder
    basePath = 'C:\Users\shlok\OneDrive\Desktop\YFR\YFR_project';
    fileName = fullfile(basePath, 'Fluid_saturation_CSVs', 'Ethane_sat.csv');
    
    if ~isfile(fileName)
        error('MISSING FILE: Run Part B script first!');
    end

    % Load dataset without worrying about "fancy" variable names [cite: 90]
    data = readtable(fileName, 'VariableNamingRule', 'preserve');
    
    % --- FIX: Extract by COLUMN INDEX to avoid "Variable Name" errors ---
    % Col 1: Fluid, Col 2: T, Col 3: P_sat, Col 4: rho_liq, Col 5: rho_vap 
    T = data{:, 2}; 
    rho_liq = data{:, 4}; 
    rho_vap = data{:, 5};

    % Ethane Constants [cite: 171]
    Tc = 305.32; 
    rhoc = 206.18; 
    
    % Question C1: Reduced variables for stability [cite: 110, 114]
    Tr = T ./ Tc; 
    xi = (rho_liq - rho_vap) ./ rhoc; 
    
    % Question C3: ADF Template (1-Tr) 
    tau = 1 - Tr;

    % Numerical cleaning for GPTIPS stability [cite: 39, 49]
    clean_idx = ~isnan(Tr) & ~isnan(xi) & ~isinf(Tr) & ~isinf(xi);
    Tr = Tr(clean_idx);
    tau = tau(clean_idx);
    xi = xi(clean_idx);

    % Question C2: GPTIPS2F Configuration [cite: 117, 122]
    gp.userdata.xtrain = [Tr(:), tau(:)]; % Inputs: Tr and tau
    gp.userdata.ytrain = xi(:); % Target: xi
    
    gp.nodes.inputs.names = {'Tr', 'tau'};
    gp.nodes.inputs.num_inp = 2;
    
    % Evolution settings [cite: 124, 126]
    gp.nodes.functions.name = {'plus', 'minus', 'times', 'sqrt', 'square'};
    gp.runcontrol.pop_size = 200; 
    gp.runcontrol.num_gen = 100; 
    gp.genes.max_genes = 4;
    gp.genes.multigene = true;
    gp.opts.pareto = 1; 
end