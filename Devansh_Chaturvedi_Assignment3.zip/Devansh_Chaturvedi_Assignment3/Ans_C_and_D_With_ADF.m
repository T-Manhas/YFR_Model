clear;
close all;
clc;

%%
gp = rungp(@ethane_config);

%%
popbrowser(gp); 

%%
runtree(gp, 'best');

% Evaluated other models using runtree(gp,<model_id>)

%%
function gp = ethane_config(gp)
    data = readtable('Ethane.csv');
    T = data.Temperature;
    P = data.SaturationPressure;
    T_train = T(1:22);
    T_test = T(23:29);
    P_train = P(1:22);
    P_test = P(23:29);
    Tc = 305.32;
    Pc = 48.7e5; 
    Tr_train = T_train./Tc;
    Tr_test = T_test/Tc;
    tau_train = 1 - Tr_train;
    tau_test = 1 - Tr_test;
    beta = 0.325;
    xi_train = plog(P_train./Pc);
    xi_test = plog(P_test./Pc);

    X_train = [tau_train, plog(tau_train), tau_train.^beta];
    X_test = [tau_test, plog(tau_test), tau_test.^beta];
    Y_train = xi_train;
    Y_test = xi_test;

    gp.nodes.inputs.names = {'tau','logtau','tauBeta'};
    gp.selection.tournament.p_pareto = 0.4; 
    gp.fitness.complexityMeasure = 0; 
    gp.selection.tournament.lex_pressure = true;
    gp.userdata.xtrain = X_train;
    gp.userdata.ytrain = Y_train;
    gp.userdata.xtest = X_test;
    gp.userdata.ytest = Y_test;
    gp.nodes.functions.name = {'plus','minus','times','rdivide','plog','sqrt','exp'};    
    gp.runcontrol.pop_size = 200;
    gp.runcontrol.num_gen = 50;
    gp.genes.max_genes = 4;
end