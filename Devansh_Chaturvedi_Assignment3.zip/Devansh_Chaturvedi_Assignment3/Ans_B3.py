import pandas as pd

fluids = [
    "Water", "Air", "Ammonia", "CarbonDioxide", "Nitrogen", 
    "Oxygen", "Hydrogen", "Helium", "Argon", "Methane", 
    "Ethane", "Propane", "n-Butane", "IsoButane", "n-Pentane", 
    "Isopentane", "n-Hexane", "n-Heptane", "n-Octane", "Ethanol", 
    "Methanol", "Acetone", "Benzene", "Toluene", "R11", 
    "R12", "R13", "R14", "R22", "R23", 
    "R32", "R123", "R124", "R125", "R134a", 
    "R141b", "R142b", "R143a", "R152A", "R245fa", 
    "R404A", "R407C", "R410A", "R507A", "R1233zd(E)", 
    "R1234yf", "R1234ze(E)", "Ethylene", "Propylene", "Xenon"
]

unstable_fluids = []

n_points_removed = 0
for fluid in fluids:

    data = pd.read_csv(f'{fluid}.csv')

    # Removing NaN values
    nan_entries = data.isna().any(axis=1).sum()
    n_points_removed += nan_entries
    data = data.dropna()

    # Removing negative Pressure entries
    neg_pressure = (data['Saturation Pressure']<0).sum()
    n_points_removed += neg_pressure
    data = data[data['Saturation Pressure']>=0]

    # Non physical densities checked in Ans_B1 while checking invalid thermodynamic states

    # Sorting values by temperature
    data = data.sort_values(by='Temperature')

    # Removing non-monotonic temperatures
    non_monotonic = (data['Temperature'].diff() <= 0).sum()
    n_points_removed += non_monotonic
    data = data[data['Temperature'].diff() > 0]

    if (nan_entries > 0 or neg_pressure > 0 or non_monotonic > 0):
        unstable_fluids.append(fluid)

    data.to_csv(f'{fluid}.csv',index=None)

print(f'Unstable Fluids: {unstable_fluids}')
print(f'From individual datasets, {n_points_removed} entries are removed')



# Preprocessing Master Dataset

n_points_removed = 0
data = pd.read_csv(f'Master_Dataset.csv')

# Removing NaN entries
n_points_removed += data.isna().any(axis=1).sum()
data = data.dropna()

# Removing negative Pressure entries
n_points_removed += (data['Saturation Pressure']<0).sum()
data = data[data['Saturation Pressure']>=0]

# Sorting entries by temperature
data = data.sort_values(by=['Temperature'])

data.to_csv(f'Master_Dataset.csv',index=None)

print(f'From Master Dataset, {n_points_removed} entries are removed')