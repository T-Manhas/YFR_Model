import CoolProp, csv
from CoolProp.CoolProp import PropsSI
import pandas as pd

fluids = [
    "Water", "Air", "Ammonia", "CarbonDioxide", "Nitrogen", 
    "Oxygen", "Hydrogen", "Helium", "Argon", "Methane", 
    "Ethane", "Propane", "n-Butane", "IsoButane", "n-Pentane", 
    "Isopentane", "n-Hexane", "n-Heptane", "n-Octane", "Ethanol", 
    "Methanol", "Acetone", "Benzene", "Toluene", "R11", 
    "R12", "R13", "R14", "R22", "R23", 
    "R32", "R123", "R124", "R125", "R134a", 
    "R141b", "R142b", "R143a", "R152A", "R245fa", 
    "R404A", "R407C", "R410A", "R507A", "R1233zd(E)", 
    "R1234yf", "R1234ze(E)", "Ethylene", "Propylene", "Xenon"
]
with open('error_log_(Ans B2).csv','a') as f:
    writer = csv.writer(f)
    writer.writerow(['Fluid','Temperature','Error'])

for fluid in fluids:
    fluid_data = [['Temperature','Saturation Pressure','Liquid Density','Vapor Density'],]
    epsilon = 0.5
    triple_temp = PropsSI('Ttriple','',0,'',0,fluid)
    critical_temp = PropsSI('Tcrit','',0,'',0,fluid)
    T_curr = triple_temp + epsilon
    while (T_curr<=critical_temp-epsilon):

        try:
            P_sat = PropsSI('P','T',T_curr,'Q',0,fluid)
            p_liq = PropsSI('D','T',T_curr,'Q',0,fluid)
            p_vap = PropsSI('D','T',T_curr,'Q',1,fluid)
            if (P_sat<0):
                with open('error_log_(Ans B2).csv','a') as f:
                    writer = csv.writer(f)
                    writer.writerow([f'{fluid}',f'{T_curr}','Negative Pressure'])

            elif(p_liq<p_vap or p_liq<=0 or p_vap<=0):
                with open('error_log_(Ans B2).csv','a') as f:
                    writer = csv.writer(f)
                    writer.writerow([f'{fluid}',f'{T_curr}','Invalid Densities'])
            
            else:
                fluid_data.append([T_curr,P_sat,p_liq,p_vap])

        except Exception:
            with open('error_log_(Ans B2).csv','a') as f:
                writer = csv.writer(f)
                writer.writerow([f'{fluid}',f'{T_curr}','Convergence failed'])

        finally:
            if (T_curr - triple_temp < 5):
                T_curr = T_curr + 0.5
            elif (critical_temp - T_curr < 5):
                T_curr = T_curr + 0.5
            else:
                T_curr = T_curr + 10

    with open(f'{fluid}.csv','w') as fobj:
        writer = csv.writer(fobj)
        writer.writerows(fluid_data)

    with open('Master_Dataset.csv','a') as fobj:
        writer = csv.writer(fobj)
        if (fluid=='Water'):
            writer.writerows(fluid_data)
        else:
            fluid_data.remove(['Temperature','Saturation Pressure','Liquid Density','Vapor Density'])
            writer.writerows(fluid_data)