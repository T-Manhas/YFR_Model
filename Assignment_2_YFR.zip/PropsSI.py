import numpy as np
import pandas as pd
from CoolProp.CoolProp import PropsSI

# Fluid1 : Methane
T_range_CH4 = np.linspace(90, 250, 50)
P_range_CH4 = np.linspace(0.5e6, 2.0e6, 10) 

'''The pressure range for methane is kept below its critical pressure (≈4.6 MPa), where liquid
and vapor phases are still well defined. At around 1 MPa, methane has a saturation
temperature of about 111 K, so choosing temperatures well below and above this value
allows both subcooled liquid and superheated vapor states to be captured, while two-phase
states are filtered out using phase identification.'''

Results_Methane = []
for P in P_range_CH4:
  for T in T_range_CH4:

    try:
      phase = PropsSI('Phase', 'T', T, 'P', P, 'Methane')

      if phase in [0, 6]:
        rho_methane = PropsSI('D', 'T', T, 'P', P, 'Methane')
        Results_Methane.append([T, P, rho_methane])
    except Exception:
        continue
    
df_methane = pd.DataFrame(Results_Methane, columns=['Temperature (K)', 'Pressure (Pa)', 'Density (kg/m3)']) 

df_methane.to_csv('Methane.csv', index=False)


# Fluid2 : R134a
T_range_R134a = np.linspace(240, 450, 50)
P_range_R134a = np.linspace(0.5e6, 2.0e6, 10)

'''The pressure range for R134a is kept below its critical pressure (≈4.06 MPa), where liquid
and vapor phases are still well defined. At around 0.1 MPa, R134a has a saturation
temperature of about 247 K, so choosing temperatures well below and above this value
allows both subcooled liquid and superheated vapor states to be captured, while two-phase
states are filtered out using phase identification.'''

Results_R134a = []
for P in P_range_R134a:
  for T in T_range_R134a:

    try:
      phase = PropsSI('Phase', 'T', T, 'P', P, 'R134a')

      if phase in [0, 6]:
        rho_R134a = PropsSI('D', 'T', T, 'P', P, 'R134a')
        Results_R134a.append([T, P, rho_R134a])

    except Exception:
      continue


df_R134a = pd.DataFrame(Results_R134a, columns=['Temperature (K)', 'Pressure (Pa)', 'Density (kg/m3)']) 

df_R134a.to_csv('R134a.csv', index=False)