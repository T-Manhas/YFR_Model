import numpy as np
import pandas as pd
from CoolProp.CoolProp import PropsSI, PhaseSI


def generate_tp_rho_dataset(
    fluid: str,
    T_min: float, T_max: float, nT: int,
    P_min: float, P_max: float, nP: int
) -> pd.DataFrame:
    """
    Generate a dataset of (T, P, rho) using CoolProp.
    Uses SI units: T [K], P [Pa], rho [kg/m^3].
    Skips invalid states and two-phase states.
    """
    T_grid = np.linspace(T_min, T_max, nT)
    P_grid = np.linspace(P_min, P_max, nP)

    rows = []
    skipped_invalid = 0
    skipped_twophase = 0

    for T in T_grid:
        for P in P_grid:
            try:
                # Phase check to avoid two-phase states
                phase = PhaseSI("T", float(T), "P", float(P), fluid)
                if "twophase" in phase.lower():
                    skipped_twophase += 1
                    continue

                rho = PropsSI("D", "T", float(T), "P", float(P), fluid)

                # Basic sanity check
                if not np.isfinite(rho) or rho <= 0:
                    skipped_invalid += 1
                    continue

                rows.append((T, P, rho))

            except Exception:
                skipped_invalid += 1
                continue

    df = pd.DataFrame(rows, columns=["Temperature_K", "Pressure_Pa", "Density_kg_m3"])

    print(f"\nFluid: {fluid}")
    print(f"Generated points: {len(df)}")
    print(f"Skipped (two-phase): {skipped_twophase}")
    print(f"Skipped (invalid/error): {skipped_invalid}")

    return df


def main():
    # ---- Domains chosen in C1 (above critical pressure to avoid two-phase) ----
    configs = [
        # Methane
        {"fluid": "Methane", "T_min": 200.0, "T_max": 500.0, "nT": 80,
         "P_min": 6e6, "P_max": 2e7, "nP": 80,
         "csv": "methane_Tp_rho.csv"},

        # R134a
        {"fluid": "R134a", "T_min": 250.0, "T_max": 450.0, "nT": 80,
         "P_min": 5e6, "P_max": 2e7, "nP": 80,
         "csv": "r134a_Tp_rho.csv"},
    ]

    for cfg in configs:
        df = generate_tp_rho_dataset(
            fluid=cfg["fluid"],
            T_min=cfg["T_min"], T_max=cfg["T_max"], nT=cfg["nT"],
            P_min=cfg["P_min"], P_max=cfg["P_max"], nP=cfg["nP"],
        )
        df.to_csv(cfg["csv"], index=False)
        print(f"Saved: {cfg['csv']}")


if __name__ == "__main__":
    main()
