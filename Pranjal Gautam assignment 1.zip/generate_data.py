# ASSIGNMENT PART C: Dataset Generation
import CoolProp.CoolProp as CP
import numpy as np
import pandas as pd

print("=== GENERATING THERMODYNAMIC DATASETS ===")

def make_data(fluid, T1, T2, p1, p2, n=30):
    """Create T-p-ρ data avoiding two-phase"""
    data = []
    for T in np.linspace(T1, T2, n):
        for P in np.linspace(p1, p2, n):
            try:
                rho = CP.PropsSI('D', 'T', T, 'P', P, fluid)
                data.append([T, P, rho])
            except:
                pass  # Skip invalid states
    return pd.DataFrame(data, columns=['T_K', 'P_Pa', 'Rho_kg_m3'])

print("\n1. METHANE (avoid critical: 190.6K, 4.6MPa)")
print("   T: 150-300K, P: 1-50 bar")
df_methane = make_data('Methane', 150, 300, 1e5, 5e6)
df_methane.to_csv('methane.csv', index=False)
print(f"   Points: {len(df_methane)}")

print("\n2. R134a (avoid critical: 374.2K, 4.06MPa)")
print("   T: 250-400K, P: 1-30 bar")
df_r134a = make_data('R134a', 250, 400, 1e5, 3e6)
df_r134a.to_csv('r134a.csv', index=False)
print(f"   Points: {len(df_r134a)}")

print("\n DONE! Files saved:")
print("   - methane.csv")
print("   - r134a.csv")
print("\nOpen files in VS Code to view data.")