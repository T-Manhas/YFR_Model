%% PART C: RESULTS EXTRACTION
clear all; close all; clc;

% Load  data if needed
if ~exist('gp', 'var')
    load('ethane_complete_results.mat');
end

%% 1. BEST MODEL INFORMATION
fprintf('\n========================================\n');
fprintf('BEST MODEL RESULTS\n');
fprintf('========================================\n');

if isfield(gp, 'results') && isfield(gp.results, 'best')
    best_model = gp.results.best;
    
    fprintf('\nBest Model:\n');
    fprintf('-----------\n');
    
    % Expression
    if isfield(best_model, 'expression')
        fprintf('Expression:\n');
        try
            gppretty(best_model.expression);
        catch
            disp(best_model.expression);
        end
    end
    
    % Fitness (RMSE)
    if isfield(best_model, 'fitness')
        fprintf('\nRMSE: %.6f\n', best_model.fitness);
    end
    
    % Complexity
    if isfield(best_model, 'complexity')
        fprintf('Complexity: %d nodes\n', best_model.complexity);
    end
end

%% 2. FITNESS PROGRESS PLOT
figure('Position', [100 100 800 500]);

if isfield(gp.results, 'history') && isfield(gp.results.history, 'bestfitness')
    best_fitness = gp.results.history.bestfitness;
    mean_fitness = gp.results.history.meanfitness;
    
    plot(0:length(best_fitness)-1, best_fitness, 'b-', 'LineWidth', 2, 'DisplayName', 'Best Fitness');
    hold on;
    plot(0:length(mean_fitness)-1, mean_fitness, 'r--', 'LineWidth', 2, 'DisplayName', 'Mean Fitness');
    xlabel('Generation');
    ylabel('Fitness (RMSE)');
    title('GPTIPS Evolution Progress');
    legend('Location', 'northeast');
    grid on;
    
    saveas(gcf, 'Fitness_Progress.png');
    fprintf('\n Fitness progress plot saved: Fitness_Progress.png\n');
end

%% 3. FOR REPORT - 
fprintf('\n========================================\n');
fprintf('FOR YOUR REPORT - QUESTION C2\n');
fprintf('========================================\n');
fprintf('\nGPTIPS2F Configuration:\n');
fprintf('  • Population size: 30\n');
fprintf('  • Generations: 20\n');
fprintf('  • Function set: times, plus, minus, rdivide\n');
fprintf('  • Selection: Pareto tournament (size 4)\n');
fprintf('\nResults:\n');
fprintf('  • Best RMSE: %.6f\n', best_model.fitness);
if isfield(best_model, 'complexity')
    fprintf('  • Model complexity: %d nodes\n', best_model.complexity);
end

%% 4. SAVE THE BEST MODEL EXPRESSION TO A FILE
if isfield(best_model, 'expression')
    fid = fopen('best_model_expression.txt', 'w');
    fprintf(fid, 'Best Model Expression:\n');
    fprintf(fid, '----------------------\n');
    
    % Try to get string representation
    try
        expr_str = gppretty(best_model.expression, 'string');
        fprintf(fid, '%s\n', expr_str);
    catch
        fprintf(fid, '%s\n', char(best_model.expression));
    end
    
    fprintf(fid, '\nRMSE: %.6f\n', best_model.fitness);
    fclose(fid);
    fprintf('\n Best model saved to: best_model_expression.txt\n');
end

%% 5. GENERATE PREDICTIONS PLOT 
try
    % Load original data if needed
    if ~exist('Tr', 'var') || ~exist('xi', 'var')
        data = readtable('C:\Users\Pranjal Gautam\OneDrive\Desktop\assignment 3\assignment3_data_20260312_003854\cleaned\Ethane_saturation_CLEANED.csv');
        Tr = data.T_K / 305.32;
        xi = log(data.p_sat_Pa / 4.87e6);
    end
    
    % Get predictions
    y_pred = gpmodel(best_model.expression, gp.nodes.functions, Tr(:));
    
    figure('Position', [100 100 1000 400]);
    
    % Actual vs Predicted
    subplot(1,2,1);
    plot(xi, y_pred, 'b.', 'MarkerSize', 8);
    hold on;
    plot([min(xi) max(xi)], [min(xi) max(xi)], 'r-', 'LineWidth', 2);
    xlabel('Actual ξ');
    ylabel('Predicted ξ');
    title('Actual vs Predicted');
    grid on;
    axis equal;
    
    % Residuals
    subplot(1,2,2);
    residuals = xi - y_pred;
    plot(xi, residuals, 'b.', 'MarkerSize', 8);
    hold on;
    plot([min(xi) max(xi)], [0 0], 'r-', 'LineWidth', 2);
    xlabel('Actual ξ');
    ylabel('Residuals');
    title('Residual Plot');
    grid on;
    
    sgtitle('Ethane Symbolic Regression Results');
    saveas(gcf, 'Ethane_Results.png');
    fprintf(' Results plot saved: Ethane_Results.png\n');
    
catch ME
    fprintf('\nNote: Could not generate predictions plot: %s\n', ME.message);
end

fprintf('\n PART C COMPLETE!\n');