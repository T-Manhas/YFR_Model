function gp = ethane_config(gp)
% Load data
load ethane_data.mat;
gp.userdata.xtrain = Tr(:);
gp.userdata.ytrain = xi(:);
gp.runcontrol.pop_size = 30;
gp.runcontrol.num_gen = 20;
gp.nodes.functions.name = {'times','plus','minus','rdivide'};
gp.selection.method = 'pareto';
gp.selection.tournament.size = 4;
gp.fitness.fitfun = @regressmulti_fitfun;
end
