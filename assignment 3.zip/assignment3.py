"""
Assignment 3 - Part B: Saturation Dataset Generation

"""

import CoolProp.CoolProp as CP
import pandas as pd
import numpy as np
import os
import time
from datetime import datetime

# List of 50 fluids (comprehensive list)
FLUIDS = [
    # Alkanes (Hydrocarbons)
    'Methane', 'Ethane', 'Propane', 'Butane', 'Pentane',
    'Hexane', 'Heptane', 'Octane', 'Nonane', 'Decane',
    'Isobutane', 'Isopentane', 'Neopentane',
    
    # Alkenes and Alkynes
    'Ethylene', 'Propylene', 'Acetylene',
    
    # Aromatics
    'Benzene', 'Toluene',
    
    # Refrigerants (HFCs)
    'R134a', 'R32', 'R125', 'R143a', 'R152a',
    'R1234yf', 'R1234ze', 'R227ea', 'R236fa', 'R245fa',
    
    # Refrigerants (CFCs/HCFCs)
    'R11', 'R12', 'R22', 'R123', 'R124',
    'R141b', 'R142b',
    
    # Natural refrigerants
    'Ammonia', 'CO2', 'Water', 'Nitrogen', 'Oxygen',
    'Argon', 'Helium', 'Hydrogen', 'Krypton', 'Xenon',
    
    # Other important fluids
    'SulfurDioxide', 'SulfurHexafluoride', 'CarbonMonoxide',
    'HydrogenSulfide', 'NitrousOxide', 'Methanol', 'Ethanol'
]
# Take exactly 50 fluids
FLUIDS = FLUIDS[:50]

def get_fluid_limits(fluid_name):
    """
    Get triple point and critical temperature for a fluid
    Returns: (T_triple, T_critical) in Kelvin
    """
    try:
        # Try to get triple point temperature
        T_triple = CP.PropsSI(fluid_name, 'Ttriple')
        
        # Some fluids don't have triple point defined
        # Use 0.5 * T_critical as a safe lower bound if needed
        T_critical = CP.PropsSI(fluid_name, 'Tcrit')
        
        # Validate triple point (some fluids return 0 or unrealistic values)
        if T_triple <= 0 or T_triple > T_critical:
            # Use a safe lower bound (40% of critical temperature)
            T_triple = 0.4 * T_critical
            
        return T_triple, T_critical
        
    except Exception as e:
        print(f"  Error getting limits for {fluid_name}: {str(e)[:50]}")
        return None, None

def generate_saturation_data(fluid_name, epsilon=1.0, verbose=True):
    """
    Generate saturation data for a single fluid
    
    Parameters:
    - fluid_name: str, name of the fluid
    - epsilon: float, buffer from endpoints in Kelvin
    - verbose: bool, whether to print progress
    
    Returns:
    - DataFrame with columns: Fluid, T_K, p_sat_Pa, rho_liquid_kgm3, rho_vap_kgm3
    """
    
    if verbose:
        print(f"\n{'='*60}")
        print(f"Processing: {fluid_name}")
        print(f"{'='*60}")
    
    # Get temperature limits
    T_triple, T_crit = get_fluid_limits(fluid_name)
    
    if T_triple is None or T_crit is None:
        print(f"  Could not determine temperature limits")
        return None
    
    # Define safe temperature range (avoid endpoints)
    T_min = T_triple + epsilon
    T_max = T_crit - epsilon
    
    # Ensure we have a valid range
    if T_min >= T_max:
        T_min = T_triple + 0.1 * (T_crit - T_triple)
        T_max = T_crit - 0.1 * (T_crit - T_triple)
    
    if verbose:
        print(f"  Triple point: {T_triple:.2f} K")
        print(f"  Critical point: {T_crit:.2f} K")
        print(f"  Temperature range: {T_min:.2f} K → {T_max:.2f} K")
    
    # Create temperature grid with higher resolution near critical point
    
    # Base uniform grid
    n_uniform = 150
    T_uniform = np.linspace(T_min, T_max, n_uniform)
    
    # Dense grid near critical point (last 20% of range)
    T_critical_start = 0.8 * T_crit
    if T_critical_start < T_min:
        T_critical_start = T_min + 0.7 * (T_max - T_min)
    
    n_critical = 100
    T_critical_region = np.linspace(T_critical_start, T_max, n_critical)
    
    # Combine and sort
    T_all = np.unique(np.concatenate([T_uniform, T_critical_region]))
    T_all = np.sort(T_all)
    
    if verbose:
        print(f"  Total temperature points: {len(T_all)}")
        print(f"  Base uniform: {n_uniform}, Critical region: {n_critical}")
    
    # Storage for results
    results = []
    failed_points = 0
    error_types = {'convergence': 0, 'invalid': 0, 'other': 0}
    
    # Calculate properties at each temperature
    for i, T in enumerate(T_all):
        try:
            # Calculate saturation properties
            # Q=0 for saturated liquid, Q=1 for saturated vapor
            p_sat = CP.PropsSI('P', 'T', T, 'Q', 0, fluid_name)
            rho_l = CP.PropsSI('D', 'T', T, 'Q', 0, fluid_name)
            rho_v = CP.PropsSI('D', 'T', T, 'Q', 1, fluid_name)
            
            # Validate results
            if p_sat <= 0 or rho_l <= 0 or rho_v <= 0:
                error_types['invalid'] += 1
                failed_points += 1
                continue
                
            # Physical consistency check: liquid should be denser than vapor
            if rho_l <= rho_v:
                error_types['invalid'] += 1
                failed_points += 1
                continue
            
            # Store valid point
            results.append({
                'Fluid': fluid_name,
                'T_K': round(T, 3),
                'p_sat_Pa': round(p_sat, 3),
                'rho_liquid_kgm3': round(rho_l, 5),
                'rho_vap_kgm3': round(rho_v, 5)
            })
            
        except CP.CoolPropError as e:
            # Convergence or input errors
            error_types['convergence'] += 1
            failed_points += 1
        except Exception as e:
            error_types['other'] += 1
            failed_points += 1
        
        # Progress indicator
        if verbose and (i+1) % 50 == 0:
            print(f"  Progress: {i+1}/{len(T_all)} points processed")
    
    # Create DataFrame
    if len(results) > 0:
        df = pd.DataFrame(results)
        
        if verbose:
            print(f"\n  Summary for {fluid_name}:")
            print(f"     Valid points: {len(df)}")
            print(f"     Failed points: {failed_points}")
            print(f"      - Convergence errors: {error_types['convergence']}")
            print(f"      - Invalid values: {error_types['invalid']}")
            print(f"      - Other errors: {error_types['other']}")
            print(f"    Temperature range: {df['T_K'].min():.2f} - {df['T_K'].max():.2f} K")
            print(f"    Pressure range: {df['p_sat_Pa'].min():.2e} - {df['p_sat_Pa'].max():.2e} Pa")
        
        return df
    else:
        if verbose:
            print(f"   No valid data points for {fluid_name}")
        return None

def main():
    """
    Main function to generate datasets for all fluids
    """
    
    # Create output directory
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = f"assignment3_data_{timestamp}"
    individual_dir = os.path.join(output_dir, "individual")
    os.makedirs(individual_dir, exist_ok=True)
    
    print("="*70)
    print("ASSIGNMENT 3 - PART B: SATURATION DATASET GENERATION")
    print("="*70)
    print(f"Output directory: {output_dir}")
    print(f"Total fluids to process: {len(FLUIDS)}")
    print("="*70)
    
    # Store all data for master file
    all_data = []
    failed_fluids = []
    summary = []
    
    # Process each fluid
    start_time = time.time()
    
    for idx, fluid in enumerate(FLUIDS, 1):
        print(f"\n[{idx:02d}/{len(FLUIDS)}] {fluid}")
        
        # Generate data
        df = generate_saturation_data(fluid, verbose=True)
        
        if df is not None and len(df) > 10:
            # Save individual file
            filename = os.path.join(individual_dir, f"{fluid}_saturation.csv")
            df.to_csv(filename, index=False)
            
            # Add to master list
            all_data.append(df)
            
            # Store summary
            summary.append({
                'Fluid': fluid,
                'Points': len(df),
                'T_min': df['T_K'].min(),
                'T_max': df['T_K'].max(),
                'P_min': df['p_sat_Pa'].min(),
                'P_max': df['p_sat_Pa'].max()
            })
            
            print(f"   Saved: {filename}")
        else:
            failed_fluids.append(fluid)
            print(f"   Failed to generate data")
    
    # Calculate elapsed time
    elapsed_time = time.time() - start_time
    
    # Create master dataset
    if all_data:
        master_df = pd.concat(all_data, ignore_index=True)
        master_file = os.path.join(output_dir, "master_saturation_dataset.csv")
        master_df.to_csv(master_file, index=False)
        
        # Create summary DataFrame
        summary_df = pd.DataFrame(summary)
        summary_file = os.path.join(output_dir, "generation_summary.csv")
        summary_df.to_csv(summary_file, index=False)
        
        # Print final summary
        print("\n" + "="*70)
        print("GENERATION COMPLETE - SUMMARY")
        print("="*70)
        print(f"Time elapsed: {elapsed_time:.1f} seconds")
        print(f"Successful fluids: {len(all_data)}/{len(FLUIDS)}")
        print(f"Failed fluids: {len(failed_fluids)}")
        if failed_fluids:
            print(f"  Failed: {', '.join(failed_fluids)}")
        print(f"\nTotal data points: {len(master_df):,}")
        print(f"\nFiles saved in: {output_dir}")
        print(f"  - Master file: master_saturation_dataset.csv")
        print(f"  - Individual files: individual/")
        print(f"  - Summary: generation_summary.csv")
        
        # Preview master file
        print("\n" + "="*70)
        print("MASTER DATASET PREVIEW (first 5 rows)")
        print("="*70)
        print(master_df.head().to_string())
        
        # Statistics by fluid
        print("\n" + "="*70)
        print("STATISTICS BY FLUID")
        print("="*70)
        stats = master_df.groupby('Fluid').agg({
            'T_K': ['min', 'max', 'count'],
            'p_sat_Pa': ['min', 'max']
        }).round(2)
        print(stats)
        
        return master_df, summary_df, failed_fluids, output_dir
    else:
        print("\n No data generated for any fluid!")
        return None, None, failed_fluids, output_dir

# Run the script
if __name__ == "__main__":
    master_df, summary_df, failed_fluids, output_dir = main()