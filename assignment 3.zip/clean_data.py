"""
PART B3: Data Cleaning 
"""

import pandas as pd
import os

print("="*60)
print("PART B3: DATA CLEANING")
print("="*60)

# ============================================
# STEP 1: FIND YOUR DATA
# ============================================
data_folder = "assignment3_data_20260312_003854"
master_file = os.path.join(data_folder, "master_saturation_dataset.csv")

print(f"\n Looking for: {master_file}")

# Check if file exists
if not os.path.exists(master_file):
    print(" ERROR: File not found!")
    print("\nCurrent folder:", os.getcwd())
    print("\nFiles here:")
    for f in os.listdir('.'):
        print(f"  - {f}")
    exit()

# ============================================
# STEP 2: LOAD DATA
# ============================================
print("\n Loading data...")
df = pd.read_csv(master_file)
print(f" Loaded: {len(df)} total points")
print(f" Fluids: {df['Fluid'].nunique()}")

# ============================================
# STEP 3: CLEAN DATA (SUPER SIMPLE)
# ============================================
print("\n Cleaning data...")

before = len(df)

# Remove any bad rows
df = df.dropna()                                   # Remove NaN
df = df[df['p_sat_Pa'] > 0]                        # Positive pressure
df = df[df['rho_liquid_kgm3'] > 0]                 # Positive liquid density
df = df[df['rho_vap_kgm3'] > 0]                    # Positive vapor density

# Sort properly
df = df.sort_values(['Fluid', 'T_K'])

after = len(df)
removed = before - after

print(f" Before: {before} points")
print(f" After: {after} points")
print(f" Removed: {removed} points")

# ============================================
# STEP 4: CREATE OUTPUT FOLDER
# ============================================
cleaned_dir = os.path.join(data_folder, "cleaned")
os.makedirs(cleaned_dir, exist_ok=True)
print(f"\n Output folder: {cleaned_dir}")

# ============================================
# STEP 5: SAVE CLEANED FILES
# ============================================
# Save master file
master_cleaned = os.path.join(cleaned_dir, "master_saturation_dataset_CLEANED.csv")
df.to_csv(master_cleaned, index=False)
print(f" Saved: master_saturation_dataset_CLEANED.csv")

# Save Ethane file (for Part C)
ethane_df = df[df['Fluid'] == 'Ethane'].copy()
ethane_file = os.path.join(cleaned_dir, "Ethane_saturation_CLEANED.csv")
ethane_df.to_csv(ethane_file, index=False)
print(f" Saved: Ethane_saturation_CLEANED.csv ({len(ethane_df)} points)")

# ============================================
# STEP 6: CREATE SIMPLE REPORT
# ============================================
report_file = os.path.join(cleaned_dir, "B3_Report.txt")

with open(report_file, 'w') as f:
    f.write("="*50 + "\n")
    f.write("PART B3 - DATA CLEANING REPORT\n")
    f.write("="*50 + "\n\n")
    
    f.write("1. CLEANING STATISTICS\n")
    f.write(f"   Original points: {before}\n")
    f.write(f"   Final points: {after}\n")
    f.write(f"   Removed: {removed}\n")
    f.write(f"   Removal %: {(removed/before*100):.1f}%\n\n")
    
    f.write("2. FLUIDS\n")
    f.write(f"   Total fluids: {df['Fluid'].nunique()}\n")
    f.write(f"   Failed fluids: Acetylene, R1234ze\n\n")
    
    f.write("3. ETHANE DATA (for Part C)\n")
    f.write(f"   Points: {len(ethane_df)}\n")
    f.write(f"   Temperature: {ethane_df['T_K'].min():.1f} - {ethane_df['T_K'].max():.1f} K\n")
    f.write(f"   Pressure: {ethane_df['p_sat_Pa'].min():.2e} - {ethane_df['p_sat_Pa'].max():.2e} Pa\n")

print(f" Saved: B3_Report.txt")

# ============================================
# STEP 7: SHOW ETHANE DATA
# ============================================
print("\n" + "="*60)
print("ETHANE DATA PREVIEW (first 5 rows)")
print("="*60)
print(ethane_df.head())

print("\n" + "="*60)
print(" PART B3 COMPLETE!")
print("="*60)
print(f"\n Your cleaned files are in: {cleaned_dir}")
print("   - master_saturation_dataset_CLEANED.csv")
print("   - Ethane_saturation_CLEANED.csv")
print("   - B3_Report.txt")